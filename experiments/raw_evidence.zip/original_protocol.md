# merge_balance_v1: does immediate redistribution pay off?

**Question:** for the same prescribed particle coalescence events, does balancing
ownership reduce total MPI simulation time compared with retaining ownership?

This is a controlled MPI workload experiment. Gaia supplies initial coordinates
and masses; which particles merge and when is deliberately synthetic. Do not
present it as a physical collision simulation or compare its timings directly to
the earlier radius-based pilot as an implementation improvement.

## Fixed design

- 1,000 input particles, initially at rest; 100 integration steps; dt=0.01 and
  softening=0.01, using the original serial force kernel and kick/drift updates.
- Four MPI ranks on one fully reserved 24-slot course node; one allocation holds
  both policies and all five paired repeats. Execution order alternates.
- Eight events, at steps 10,20,30,40,50,60,70,80, each BEFORE the force calculation.
- Each event merges 12 disjoint pairs; fixed immutable IDs come from original CSV
  row numbers. IDs are not current array indices. The merged ID is the smaller ID.
- Most scheduled IDs start in rank 0's block, intentionally making retained
  ownership uneven. One pair crosses the original rank-0/rank-1 boundary.
- Exactly 96 particles disappear, leaving 904. There is no radius-based detection
  in this experiment and no repeated force pass at an event.

`data/schedule.json` is the exact event list. Both policies use that file, including
the same IDs, even after ownership changes. Pair distances are irrelevant here.
Mass is summed; position and velocity are mass-weighted, as in the existing merge
function. Energy is not conserved by this coalescence rule.

## Policies

**immediate:** after each event, rebuild equal-sized contiguous blocks in canonical
ID order. Final ownership at P=4 is [226,226,226,226].

**retained:** each surviving particle keeps its process owner. A merged particle
inherits the owner of its smaller ID. Final ownership at P=4 is [155,249,250,250].
Updating variable counts, local arrays and communication layouts is still required;
"retained" does NOT mean leaving stale MPI counts after particles disappear.

Every rank holds canonical global positions and masses. Allgatherv gathers local
positions in process order and explicitly restores canonical ID order before force
calculations. This preserves the summation order despite ownership changes.
Each rank computes only its own rows; contiguous runs reuse the original kernel.

**Both policies gather positions AND velocities at merge events and reconstruct the
same full merged state on every rank.** Immediate redistribution uses that already
replicated state. There is no dedicated network migration or Scatterv in either
policy; logical ownership changes must not be presented as migration bytes.
This experiment measures the value of balanced work within a replicated-state
design, not the communication cost of a fully distributed migration algorithm.

## What is timed and tracked

Timing runs use the same new engine with detailed tracing disabled. Each includes
all steps, event exchanges, merge computation, layout rebuilding, force exchanges,
force computation, integration, collective time-limit checks and a final barrier.
Input loading, final-state gathering, CSV output and validation are outside the
timed interval. There is no per-step file I/O and no additional per-step trace
collective. Both policies have the same number of force evaluations and interactions.

Separate diagnostics store per-rank records in memory and gather them at the end:
ownership per step, force and exchange time, interaction counts, scheduled pair
ownership, cross-rank pairs, logical ownership changes and event-stage timings.
Force-time max/mean measures observed imbalance; count max/mean predicts force-work
imbalance. Exchange time also includes waiting, so it is not pure network latency.

## Checks before timing results are accepted

1. A 16-particle fixture with two events, including a cross-rank pair, ends at N=12.
2. Both MPI policies agree with a one-process reference at every diagnostic event
   (SHA-256 of canonical physical arrays and IDs), and in every final-state column.
3. The main workload performs eight events and ends at N=904; interaction totals
   agree with the schedule's independently calculated sum of N(t)*(N(t)-1).
4. Immediate ownership differs by at most one; retained ownership changes no
   surviving particle owners; actual retained imbalance must develop.
5. All ten timing runs complete the same steps and match the reference final state
   and interaction total. Numeric CSV comparison uses rtol=atol=1e-12; IDs and
   categories must match exactly. Mass/momentum and finite-state checks also run.

The reference uses the existing serial force and merge functions in one process;
it validates ownership/communication, not independent physical correctness.
Timing runs validate final states; only diagnostics hash every intermediate event.

## Prepare locally

From the repository root in Windows PowerShell:

```powershell
python experiments/merge_balance/prepare.py
```

Produces `experiments/merge_balance/campaigns/merge_balance_v1.zip` and a standalone
folder with code, configuration, exact data and schedule, and SHA-256 manifest.
Existing names are refused. No earlier simulation, experiment or result is modified.
To repeat in another allocation, prepare a new name, e.g. `--name merge_balance_v2`.
Defaults require the existing `gaia_subsets/gaia_nearest_1000.csv` plus NumPy/pandas.

## Upload from LOCAL PowerShell

```powershell
scp experiments/merge_balance/campaigns/merge_balance_v1.zip s225141@login.hpc.dtu.dk:~/courses/02616_LSM/gaia/merge_experiments/
ssh s225141@login.hpc.dtu.dk
```

## Extract and submit on the HPC

```bash
cd ~/courses/02616_LSM/gaia/merge_experiments
test ! -e merge_balance_v1 && unzip merge_balance_v1.zip
cd merge_balance_v1
module load pandas/2.3.0-python-3.12.11
module load matplotlib/3.10.3-numpy-2.3.1-python-3.12.11
python3 code/submit.py --dry-run
python3 code/submit.py
```

This submits ONE seven-minute job that executes the complete comparison. Generated
shell scripts have Linux newlines; settings are embedded instead of relying on
LSF forwarding environment variables. The job loads mpi4py/Open MPI and limits
BLAS/OpenMP to one thread per rank. Allocation/module/CPU/binding data go to logs.
The 24-slot reservation assumes the same course nodes as the previous pilot.

```bash
bjobs -w
tail -n 30 jobs/p4/lsf_*.out
cat jobs/p4/status.json
```

`status.json` is written when the orchestrator finishes. A missing status can mean
pending/running/killed; it does not mean success. The whole sequence shares a
walltime-minus-120-seconds budget. Each subprocess has an internal time limit;
incomplete results fail. Preserve failed logs and prepare a new campaign for retry.

## Read the result

After `status.json` says `"passed": true`:

```bash
python3 code/analyze.py
cat analysis/REPORT.md
```

The report embeds `analysis/FINDINGS.png`: ownership for BOTH policies over time,
observed force-time imbalance and every timing repeat. It explains the result
using the actual data. `event_stages.png` and CSVs expose the stage costs.

```text
merge_balance_v1/
  config.json, manifest.json, README.md
  code/                         frozen implementation and tools
  data/input.csv, schedule.json exact workload
  jobs/p4/
    submitted.sh, submission.json, lsf_JOBID.out/.err, status.json
    runs/reference/             one-process reference and event checkpoints
    runs/immediate_diagnostic/  rank_steps.csv, merge_events.csv, checkpoints.json
    runs/retained_diagnostic/   same evidence for retained ownership
    runs/immediate_repeat1/    summary.json, final.csv, validation.json, logs
    runs/retained_repeat1/     paired timing result; repeats 1..5
  analysis/REPORT.md            readable findings and limits
  analysis/FINDINGS.png         actual ownership/imbalance/timing comparison
  analysis/paired_comparison.csv
```

Download into a NEW local destination (LOCAL PowerShell at repository root):

```powershell
scp -r s225141@login.hpc.dtu.dk:~/courses/02616_LSM/gaia/merge_experiments/merge_balance_v1 experiments/merge_balance/campaigns/hpc_merge_balance_v1
```

The result applies to this deliberately uneven schedule and replicated-state
design. Repeats within one allocation estimate launch variation; they do not
establish reproducibility across nodes or days. Small effects relative to the
paired differences' variability require another allocation before a report claim.
