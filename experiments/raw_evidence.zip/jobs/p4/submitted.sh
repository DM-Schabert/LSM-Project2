#!/bin/bash
#BSUB -J merge_balance_v1_p4
#BSUB -q hpcintro
#BSUB -n 24
#BSUB -R "span[hosts=1]"
#BSUB -R "rusage[mem=2GB]"
#BSUB -W 7
#BSUB -o /zhome/a4/6/187727/courses/02616_LSM/gaia/merge_experiments/merge_balance_v1/jobs/p4/lsf_%J.out
#BSUB -e /zhome/a4/6/187727/courses/02616_LSM/gaia/merge_experiments/merge_balance_v1/jobs/p4/lsf_%J.err
set -euo pipefail
cd /zhome/a4/6/187727/courses/02616_LSM/gaia/merge_experiments/merge_balance_v1
module load pandas/2.3.0-python-3.12.11
module load matplotlib/3.10.3-numpy-2.3.1-python-3.12.11
module load mpi4py/4.0.3-python-3.12.11-openmpi-5.0.8
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export MPLBACKEND=Agg PYTHONUNBUFFERED=1
echo "job $LSB_JOBID; allocated slots $LSB_DJOB_NUMPROC; hosts $LSB_MCPU_HOSTS"
module list
lscpu
python3 /zhome/a4/6/187727/courses/02616_LSM/gaia/merge_experiments/merge_balance_v1/code/run_job.py --ranks 4
